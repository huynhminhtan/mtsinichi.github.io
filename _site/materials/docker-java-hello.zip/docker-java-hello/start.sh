#!/bin/sh
echo "Workspace dir: " $PWD
# pwd
# ls
# cat HelloWorld.java
javac HelloWorld.java
java HelloWorld
# exec $@